#ifndef ORIENTATIONDEPLACEMENT_
#define ORIENTATIONDEPLACEMENT_
#include <iostream>
using namespace std;

enum class OrientationDeplacement{ 
    NORD, SUD, EST, OUEST
};
#endif