#include "../../include/Modele/Piece.hpp"

void Piece::trigger(const pair<int,int> & coord ) { trigger(coord, *this); }